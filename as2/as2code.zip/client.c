/*
 *
 *  The tcpechotimesrv.c file is part of the assignment 1 of the Network Programming.
 *  It is a simple TCP implementation, basically, it is
 *  an academic project of CSE533 of Stony Brook University in fall
 *  2015. For more details, please refer to Readme.
 *
 *  Copyright (C) 2015 Dongju Ok   <dongju@stonybrook.edu,
 *                                  yardbirds79@gmail.com>
 *
 *  It is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  It is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License.
 *  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "unpifiplus.h"
#include "global.h"

/*
 * External Functions
 */
extern struct ifi_info 
*Get_ifi_info_plus(int family, int doaliases);
extern void 
free_ifi_info_plus(struct ifi_info *ifihead);

/*
 * Local Functions
 */


int 
main(int argc, char **argv)
{
	FILE *fp;
	struct client_arguments client_info;
	//char *IPserver;
        int server_port;
        char filename[MAXLINE];
        int sliding_window_size;
        int seed;
        float probability_loss;
        int mean_time;
	struct socket_descripts sock_desc[10];
	char buf[MAXLINE];
	int count = 0;
	struct ifi_info *ifi, *ifihead;
	struct sockaddr_in *sa;
	int i;
	char IPserver[MAXLINE], IPclient[MAXLINE];
	int sockfd;
	int sock_count = 0;
	int loopback = FALSE;

	if( (fp = fopen("client.in", "r")) == NULL)
	{
		printf("ERROR MSG: client open error\n");
		exit(1);
	}

	while (fgets(buf, MAX_LINE -1, fp) != NULL)
        {
                //printf("fgets loop %d\n", count);
		switch(count){
			case 0:
				strncpy(IPserver, buf, strlen(buf)-1);
				break;
			case 1:
				server_port = atoi(buf);
				break;
			case 2:
				strncpy(filename, buf, strlen(buf)-1);
				
				break;
			case 3:
				//TODO: adding Receving sliding-window size
				break;
			case 4: 
				seed = atoi(buf);
				break;
			case 5:
				probability_loss = atof(buf);
				break;
			case 6:
				mean_time = atof(buf);
				break;
			default:
				printf("ERROR MSG: client client.in input error\n");
				exit(1);
				break;
		}
		count++;
	}
	fclose(fp);

	client_info.IPserver = IPserver;
	client_info.server_port = server_port;
	client_info.filename = filename;
	client_info.sliding_window_size;
	client_info.seed = seed;
	client_info.probability_loss = probability_loss;
	client_info.mean_time = mean_time;
#if(1)
	/* Debug Info */
	printf("CLIENT: client_info.IPserver: %s\n", client_info.IPserver);
	printf("CLIENT: client_info.filename: %s\n", client_info.filename);
#endif

	for (ifihead = ifi = Get_ifi_info_plus( AF_INET, 1);
                ifi != NULL;
                ifi = ifi->ifi_next) {

                sa = (struct sockaddr_in *) ifi->ifi_addr;
                sa->sin_family = AF_INET;
                sa->sin_port = htonl(server_port);

                sock_desc[sock_count].sockfd = -1;
                sock_desc[sock_count].ip_addr = sa;
                sock_desc[sock_count].net_mask = (struct sockaddr_in *)ifi->ifi_ntmaddr;
#if(1)
		/* Debug Info */
                printf("CLIENT: sock_desc[sock_count] IP: %s\n", Sock_ntop(sock_desc[sock_count].ip_addr, sizeof(struct in_addr)));
                printf("CLIENT: Network mask: %s\n", Sock_ntop(sock_desc[sock_count].net_mask, sizeof(struct in_addr)));
#endif
		sock_count++;
	}

	/* Identify Loopback */	
	for(i=0; i < sock_count; i++)
	{
		char IPbuf[MAXLINE];
		char *p;
		char *p1;
		printf("CLIENT: 1st %s\n", Sock_ntop_host( (SA *)sock_desc[i].ip_addr, sizeof( struct in_addr *)));
		printf("CLIENT: 2nd %s\n", client_info.IPserver);

		p = sock_ntop( (SA *)(sock_desc[i].ip_addr), sizeof( struct in_addr *));
		
		p1 = strtok(p, ":");
		printf("CLIENT: debug sock_desc.ip_addr = %s\n",p1 );

		if (strcmp(p1, client_info.IPserver) == 0)
		{
			loopback = TRUE;
			strcpy(IPserver, "127.0.0.1\n");
			strcpy(sock_desc[i].ip_addr, IPserver);
			strcpy(IPclient, IPserver);
			printf("CLIENT: Loopback case\n");
			break;
		}
		else
		{
			struct in_addr ip, netmask, subnet1, subnet2, server_ip, longest_prefix_ip, longest_prefix_netmask;
        		char prefix1[MAXLINE], prefix2[MAXLINE], str_longest_prefix_ip[MAXLINE], str_longest_prefix_netmask[MAXLINE];
			
			ip =(struct in_addr)((struct sockaddr_in *)(sock_desc[i].ip_addr))->sin_addr;
			netmask = (struct in_addr) ((struct sockaddr_in *)(sock_desc[i].net_mask))->sin_addr;
			subnet1.s_addr = ip.s_addr & netmask.s_addr;

                        inet_ntop(AF_INET, &subnet1, prefix1, MAXLINE);
                        inet_pton(AF_INET, client_info.IPserver, &server_ip);
                        subnet2.s_addr = server_ip.s_addr & netmask.s_addr;
                        inet_ntop(AF_INET, &subnet2, prefix2, MAXLINE);

                        if (strcmp(prefix1, prefix2) == 0){
                                if (netmask.s_addr > longest_prefix_netmask.s_addr){
                                        longest_prefix_ip = server_ip;
                                        longest_prefix_netmask = netmask;
				
					inet_ntop( AF_INET, &longest_prefix_ip, IPserver, MAXLINE);

#if(1)
					/* Debug Info */
                                        inet_ntop(AF_INET, &longest_prefix_ip, str_longest_prefix_ip, MAXLINE);
                                        printf("CLIENT: longest_prefix_ip = %s\n",str_longest_prefix_ip);
                                        inet_ntop(AF_INET, &longest_prefix_netmask, str_longest_prefix_netmask, MAXLINE);
                                        printf("CLIENT: longest_prefix_netmask = %s\n",str_longest_prefix_netmask);
#endif
                                }
                        }
		}
	}

#if(0 )	
	/* Debug info */
	printf("CLIENT: IPserver : %s\n",IPserver);

#endif

	char sendline[MAXLINE], recvline[MAXLINE];
	struct 	sockaddr_in servaddr1;
	socklen_t servaddr1_len = sizeof(servaddr1);
	struct sockaddr_in cliaddr, servaddr;
	struct sockaddr_in serv_addr;
	socklen_t serv_addr_len = sizeof(serv_addr);
	int on=1;
	int n;	

	inet_pton( AF_INET, IPclient, &cliaddr.sin_addr );
	cliaddr.sin_family = AF_INET;
	cliaddr.sin_port = htons(0);

	sockfd = Socket(AF_INET, SOCK_DGRAM, 0);
	setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	Bind( sockfd, (SA *)&cliaddr, sizeof(cliaddr));
	printf("CLIENT: passing Bind()\n");

	if(getsockname (sockfd, (SA *) &servaddr1, &servaddr1_len) < 0)
	{
		perror("Client information could not be obtained");
		exit(0);
	}
	printf("CLIENT: passing getsockname()\n");

	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(client_info.server_port);

	inet_pton(AF_INET, client_info.IPserver, &(servaddr.sin_addr));
	Connect(sockfd, (SA *) &servaddr, sizeof(servaddr));
	printf("CLIENT: passing Connect()\n");

	bzero(&servaddr1, sizeof(servaddr1));
	if( getpeername(sockfd, (SA *) &servaddr1, &servaddr1_len) < 0)
	{ 
		printf("CLIENT: passing getpeername()\n");
		exit(1);
	}
	
	strcpy(sendline, client_info.filename);
	printf("CLIENT: sending message %s\n", sendline);
	Sendto(sockfd, sendline, strlen(sendline), MSG_DONTROUTE, 0, 0);
	printf("CLIENT: passing Sendto()\n");

#if(1)
	/* Test tracking client IP */
	sleep(1);
	Sendto(sockfd, sendline, strlen(sendline), MSG_DONTROUTE, 0, 0);
        printf("CLIENT: passing Sendto()\n");

#endif	

	
	/* receving PORT */
	Recvfrom(sockfd, recvline, MAXLINE, 0, NULL, NULL);
	printf("ClIENT: recevied port %s \n", recvline);
	
	servaddr1.sin_port = (uint16_t)atoi(recvline);
#if(1)
	/* For Debug */
	char IPbuf[MAXLINE];
	printf("CLIENT: get port num %d \n",(uint16_t)servaddr1.sin_port);
	inet_ntop( AF_INET, &(servaddr1.sin_addr), IPbuf, MAXLINE);
	printf("CLIENT: sock_store IP: %s, port: %d\n", IPbuf, (uint16_t)servaddr1.sin_port);
#endif	
	if(connect(sockfd, &servaddr1, servaddr1_len) < 0)
	{
		printf("CLIENT: connect() error after receving port num\n");
		exit(1);	
	}	
	
#if(1)
	/* For Debug */
	struct sockaddr_in sa1;
        socklen_t sa1_len = sizeof(sa1);
	struct  sockaddr_in sa2;
        socklen_t sa2_len = sizeof(sa2);
	
	if(getsockname (sockfd, (SA *) &sa1, &sa1_len) < 0)
        {
                perror("Client information could not be obtained");
                exit(0);
        }
	//printf("CLIENT: client  port: %d\n", (uint16_t)(sa1.sin_port));  

	if( getpeername(sockfd, (SA *)&sa2, &sa2_len) < 0)
        {
                printf("CLIENT: getpeeername() error\n");
                exit(1);
        }
	printf("CLIENT: client  access to port: %d\n", (uint16_t)(sa2.sin_port));
#endif
	/* ACK */
	strncpy(sendline, "I AM ACKNOWLMENT!\n", 15);
	Sendto(sockfd, sendline, strlen(sendline), MSG_DONTROUTE, 0, 0);
	printf("CLIENT: sending ACK\n");

	/* File transfer */
	Recvfrom(sockfd, recvline, MAXLINE, 0, NULL, NULL);
	printf("CLIENT: receving msg of file : %s\n", recvline);

	while(1);
}
